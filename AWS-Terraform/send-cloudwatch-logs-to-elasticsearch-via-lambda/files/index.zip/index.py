def lambda_handler(event, context):
    print("I am just creating logs")
    print("vijay mourya is creator")
