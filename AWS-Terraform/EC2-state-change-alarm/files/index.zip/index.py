import boto3
import json
def lambda_handler(event, context):
    instance_id = event['detail']['instance-id']
    M = 'Instance: '+instance_id+' has changed state\n'
    state = event['detail']["state"]
    time = event['time']
    M = M+'State: '+state+' at '+time+'\n'
    region = event["region"]
    M = M+'Region: '+region+'\n'
    resources = event["resources"][0]
    M = M+'Resource ARN: '+resources

    #ec2 = boto3.client('ec2',"ap-south-1")
    #myinstance = ec2.describe_instances(InstanceIds=[instance_id])
    #typedetails="Instance type: "myinstance[instance-type]+"\nInstance IP address: "+myinstance[ip-address]

    MY_SNS_TOPIC_ARN = "arn:aws:sns:ap-south-1:014389034315:STATE-CHANGE-simple-SNS-notify"
    sns_client = boto3.client('sns',"ap-south-1")
    sns_client.publish(
        TopicArn = MY_SNS_TOPIC_ARN,
        Subject = 'Instance Change State: '+instance_id,
        Message = M
    )
